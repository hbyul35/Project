using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : MonoBehaviour  
{
    public float raycastDistance = 1.0f;
    public float pushPullSpeed = 5.0f;
    private GameObject targetCube;
    private bool isFalling = true; // 블록이 고정된 상태를 나타내는 변수
    private bool isMoving = false; // 큐브 이동 체크
    //public float fallSpeed = 3.0f;
    private GameObject blockBorder;

    void Start()
    {
        blockBorder = GameObject.Find("BlockBorder");

    }

    void Update()
    {
        Ray playerArmray = new Ray(transform.position, transform.forward);
        RaycastHit playerArmhit;

        if (Physics.Raycast(playerArmray, out playerArmhit, raycastDistance))
        {
            Debug.DrawRay(transform.position, transform.forward * raycastDistance, Color.red);

            // 블록 tag 조건 추가함
            if (playerArmhit.collider.CompareTag("Cube") || playerArmhit.collider.CompareTag("TrapBlock") || playerArmhit.collider.CompareTag("DisposableBlock") && !playerArmhit.collider.CompareTag("HeavyBlock"))
            { 
                targetCube = playerArmhit.collider.gameObject;

                //pull
                if (Input.GetKey(KeyCode.Space) && Input.GetKeyDown(KeyCode.S)) // 이동중이 아닐때  && !isMoving 
                {
                    StartCoroutine(pulling(targetCube));
                }

                //push
                if (Input.GetKey(KeyCode.Space) && Input.GetKeyDown(KeyCode.W)) // && !isMoving 
                {
                    StartCoroutine(push(targetCube));
                }
            }  
        }
    }

    IEnumerator pulling(GameObject cubeToMove)
    {
        isMoving = true; // 시작 플래그

        Vector3 start = cubeToMove.transform.position; // 현재 위치
        Vector3 end = start - (cubeToMove.transform.forward) * cubeToMove.transform.localScale.z; // 목적지
        float journeyLength = Vector3.Distance(start, end); // public static float Distance(Vector3 a, Vector3 b);  두 벡터간의 거리를 저장

        float startTime = Time.time;
        float journeyDuration = journeyLength / pushPullSpeed; // 이동에 걸리는 예상 시간

        //Time.time - startTime 현재시간-이동시작 시간 즉 이동이 시작된후 경과한시간임
        // 현재 이동이 예상시간보다 작은지 판단 = 그니깐 이동이 아직 진행중인지 판단함 journeyDuration보다 작으면 이동중이란 말임
        while (Time.time - startTime < journeyDuration)
        {
            float distanceCovered = (Time.time - startTime) * pushPullSpeed; // 이동한 거리를 나타냄, 거리 = 시간 * 속도
            float fractionOfJourney = distanceCovered / journeyLength; // 이동한 거리 / 벡터 길이 = 이동 비율
            cubeToMove.transform.position = Vector3.Lerp(start, end, fractionOfJourney); // 보간사용 시작위치, 최종위치, 비율
            yield return null;
        }

        //이동완료 후
        cubeToMove.transform.position = end; // 목적지에 정확하게 위치시킴
        isMoving = false; // 이동 완료 후 플래그
    }

    IEnumerator push(GameObject cubeToMove)
    {
        isMoving = true;

        Vector3 start = cubeToMove.transform.position;
        Vector3 end = start - (-cubeToMove.transform.forward) * cubeToMove.transform.localScale.z;
        float journeyLength = Vector3.Distance(start, end);

        float startTime = Time.time;
        float journeyDuration = journeyLength / pushPullSpeed;

        while (Time.time - startTime < journeyDuration)
        {
            float distanceCovered = (Time.time - startTime) * pushPullSpeed;
            float fractionOfJourney = distanceCovered / journeyLength;
            cubeToMove.transform.position = Vector3.Lerp(start, end, fractionOfJourney);
            yield return null;
        }

        //이동완료 후
        cubeToMove.transform.position = end;
        isMoving = false;
    }
}
