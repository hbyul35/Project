using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 5f;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // ������ ó��
        float horizontalInput = Input.GetAxis("Horizontal"); // A, D
        float forwardInput = Input.GetAxis("Vertical"); // W, S

        Vector3 movement = new Vector3(horizontalInput, 0f, forwardInput) * speed * Time.deltaTime;

        // Translate �޼ҵ带 ����Ͽ� �̵�
        transform.Translate(movement);
    }
}